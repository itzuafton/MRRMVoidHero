import pygame
pygame.init()
pygame.mixer.init()
W,H=960,640
screen=pygame.display.set_mode((W,H))
pygame.display.set_caption("Void Hero")
clock=pygame.time.Clock()
A="assets"
IMAGES_DIR=A+"/images"
SOUNDS_DIR=A+"/sounds"
MUSIC_VOLUME=0.4
PLAYER_SPEED=4.2
MONSTER_SPEED=1.1
def img(n):return pygame.image.load(IMAGES_DIR+"/"+n+".png").convert_alpha()
SPR={n:img(n) for n in ("player","platform","spikes","monster","exit")}
BACKGROUND=pygame.transform.scale(img("background"),(W,H))
#Фоновая музыка запускается один раз и играет по кругу
pygame.mixer.music.load(SOUNDS_DIR+"/background_music.mp3")
pygame.mixer.music.set_volume(MUSIC_VOLUME)
pygame.mixer.music.play(-1)
JUMP_SOUND=pygame.mixer.Sound(SOUNDS_DIR+"/jump.wav")
COLLISION_SOUND=pygame.mixer.Sound(SOUNDS_DIR+"/collision.wav")
JUMP_SOUND.set_volume(0.2)
COLLISION_SOUND.set_volume(0.2)
font=pygame.font.SysFont("arial",22,bold=True)
big=pygame.font.SysFont("arial",48,bold=True)
SPIKE_H=SPR["spikes"].get_height()
MONSTER_H=SPR["monster"].get_height()
MONSTER_W=SPR["monster"].get_width()
LEVELS=[
("Забытые руины",(45,500),(850,322),
[(0,570,260),(300,520,220),(555,455,190),(770,535,190),(90,470,130),(280,400,150),(500,330,150),(700,380,150)],
[(380,520,64),(620,455,64),(730,380,64)],
[(150,570,160,240),(790,535,770,960),(310,400,280,430),(530,330,500,650)]),
("Кристальная пещера",(40,500),(850,232),
[(0,570,210),(250,515,200),(490,455,200),(720,385,210),(100,470,130),(310,405,140),(535,340,145),(745,290,170)],
[(300,515,64),(560,455,64),(600,340,64)],
[(110,570,20,190),(120,470,100,230),(740,385,720,930),(770,290,745,915)]),
("Путь наружу",(40,500),(790,247),
[(0,570,190),(225,520,180),(445,460,180),(665,395,180),(785,305,175),(100,470,130),(300,405,130),(505,340,130),(680,275,130)],
[(260,520,64),(480,460,64),(700,395,64),(330,405,64),(530,340,64)],
[(140,570,120,190),(810,305,785,960),(120,470,100,230),(700,275,680,810)])
]
idx=0
def make():
 name,start,exitp,ps,ss,es=LEVELS[idx]
 platforms=[pygame.Rect(x,y,w,29) for x,y,w in ps]
 spikes=[pygame.Rect(x,y-SPIKE_H,w,SPIKE_H) for x,y,w in ss]
 monsters=[{"r":pygame.Rect(x,y-MONSTER_H,MONSTER_W,MONSTER_H),"lo":lo,"hi":hi,"d":1} for x,y,lo,hi in es]
 return {"name":name,"start":start,"exit":exitp,"ps":platforms,"ss":spikes,"es":monsters}
level=make()
player=pygame.Rect(*level["start"],36,44)
vx=vy=0
grounded=False
dead=won=False
def trigger_collision():
 global dead
 # Звук столкновения проигрывается только один раз
 if not dead:
  dead=True
  COLLISION_SOUND.play()
def reset():
 global level,player,vx,vy,dead,won,grounded
 level=make()
 player=pygame.Rect(*level["start"],36,44)
 vx=vy=0
 grounded=False
 dead=won=False
def background():screen.blit(BACKGROUND,(0,0))
def update(keys):
 global vx,vy,grounded,dead,won,idx,level
 vx=0
 if keys[pygame.K_LEFT] or keys[pygame.K_a]:vx=-PLAYER_SPEED
 if keys[pygame.K_RIGHT] or keys[pygame.K_d]:vx=PLAYER_SPEED
 player.x+=int(vx)
 # Горизонтальные столкновения с платформами
 for p in level["ps"]:
  if player.colliderect(p):
   if vx>0:player.right=p.left
   elif vx<0:player.left=p.right
 vy=min(vy+.52,12)
 player.y+=int(vy)
 grounded=False
 # Вертикальные столкновения и приземление
 for p in level["ps"]:
  if player.colliderect(p):
   if vy>0:
    player.bottom=p.top
    grounded=True
   elif vy<0:player.top=p.bottom
   vy=0
 # Проверка земли, чтобы прыжок срабатывал сразу после приземления
 if not grounded:
  ground_check=player.move(0,1)
  for p in level["ps"]:
   if ground_check.colliderect(p):
    grounded=True
    break
 if player.top>H:trigger_collision()
 for s in level["ss"]:
  if player.colliderect(s):trigger_collision()
 # Монстры патрулируют участок и разворачиваются у границ
 for e in level["es"]:
  r=e["r"]
  r.x+=int(MONSTER_SPEED*e["d"])
  if r.left<e["lo"]:
   r.left=e["lo"]
   e["d"]=1
  if r.right>e["hi"]:
   r.right=e["hi"]
   e["d"]=-1
  if player.colliderect(r):trigger_collision()
 if player.colliderect(pygame.Rect(*level["exit"],48,58)):won=True
def draw():
 background()
 for p in level["ps"]:
  platform_img=pygame.transform.scale(SPR["platform"],(p.width,p.height))
  screen.blit(platform_img,(p.x,p.y))
 for s in level["ss"]:
  for x in range(s.x,s.right,32):screen.blit(SPR["spikes"],(x,s.y))
 for e in level["es"]:screen.blit(SPR["monster"],e["r"])
 screen.blit(SPR["exit"],level["exit"])
 screen.blit(SPR["player"],player)
 screen.blit(font.render(f"{idx+1}/3  {level['name']}",True,(235,245,255)),(20,16))
 screen.blit(font.render("A/D или ←/→ — движение   Space/W/↑ — прыжок   Esc — выход",True,(175,198,230)),(20,H-32))
def overlay(a,b):
 shade=pygame.Surface((W,H),pygame.SRCALPHA)
 shade.fill((0,0,0,180))
 screen.blit(shade,(0,0))
 t=big.render(a,True,(240,248,255))
 s=font.render(b,True,(180,220,255))
 screen.blit(t,t.get_rect(center=(W//2,H//2-35)))
 screen.blit(s,s.get_rect(center=(W//2,H//2+25)))
def main():
 # grounded и vy должны быть глобальными для работы прыжка
 global idx,won,vy,grounded
 run=True
 while run:
  clock.tick(60)
  for ev in pygame.event.get():
   if ev.type==pygame.QUIT:run=False
   if ev.type==pygame.KEYDOWN:
    if ev.key==pygame.K_ESCAPE:run=False
    # Звук прыжка срабатывает по одиночному нажатию клавиши
    if (ev.key in (pygame.K_SPACE,pygame.K_UP,pygame.K_w)
        and not dead and not won and grounded):
     vy=-11.8
     grounded=False
     JUMP_SOUND.play()
    if dead and ev.key==pygame.K_RETURN:reset()
    if dead and ev.key==pygame.K_r:
     idx=0
     reset()
    if won and ev.key in (pygame.K_RETURN,pygame.K_r):
     if idx<2:idx+=1
     else:idx=0
     reset()
  if not dead and not won:update(pygame.key.get_pressed())
  draw()
  if dead:overlay("Попытка не удалась","Enter — повторить уровень   R — начать заново")
  if won:overlay("Ты выбрался!" if idx==2 else "Уровень пройден!","Enter — продолжить   R — начать заново")
  pygame.display.flip()
 pygame.mixer.music.stop()
 pygame.quit()
 raise SystemExit
if __name__=="__main__":main()
